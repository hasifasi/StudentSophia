package Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class setExamples {

	public static void main(String[] args) {
		
		//hashSetExample();
		
		treeSetExample();
	}
	
	public static void hashSetExample() {
		
		HashSet<Integer> HS = new HashSet<Integer>();
		
		//LinkedHashSet<Object> LS= new LinkedHashSet<Object>();
		
		
		HS.add(5);
		HS.add(3);
		HS.add(7);
		HS.add(99);
		HS.add(7);
		HS.add(8);
		
		//LS.add(33);
		
		Iterator I= HS.iterator(); // Iterator declaration..
		
		
		while(I.hasNext()) {
			System.out.println(I.next());
		}
		
		
	}
	
	public static void treeSetExample() {
		TreeSet<Object> TS= new TreeSet<Object>();
		
		TS.add(99);
		
		TS.add(55);
		TS.add(11);
		TS.add(23);
		TS.add(78);
		
		Iterator I= TS.iterator(); // Iterator declaration..
		
		
		while(I.hasNext()) {
			System.out.println(I.next());
	}
	
	}
	
	public static void SetInterfaceExample() {
		
		Set<Integer> S= new HashSet<Integer>();
		
		Set<Integer> SL= new LinkedHashSet<Integer>();
		
		Set<Integer> ST= new TreeSet<Integer>();
	}

}
