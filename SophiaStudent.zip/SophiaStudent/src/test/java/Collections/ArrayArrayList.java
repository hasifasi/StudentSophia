package Collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ArrayArrayList {

	public static void main(String args[]) {
		//arrayExample();
		
		//arrayListExample();
		
		linkedListExample();
	}

	public static void arrayExample() {

		int[] A = new int[3]; // Array declaration..

		A[0] = 5;
		A[1] = 2;
		A[2] = 6;
			
		System.out.println("Length of A is "+A.length);

		for (int i = 0; i < A.length; i++) {
			System.out.println(A[i]);
		}

	}
	
	public static void arrayListExample() {
		
		ArrayList<Integer> AL= new ArrayList<Integer>();
		
		
		AL.add(5);
		AL.add(2);
		AL.add(6);
		AL.add(99);
		AL.add(34);
		AL.add(2);
		//AL.add("hello");
		
		System.out.println("Size of AL is "+AL.size());
		
		for(int i=0;i<AL.size();i++) {
			System.out.println(AL.get(i));
		}
		
		System.out.println(AL.get(4));
		
	}
	
	public static void linkedListExample() {
		
		LinkedList<String> LL= new LinkedList<String>();
		
		LL.add("Hello");
		LL.add("Hi");
		LL.add("Chennai");
		
		for(int j=0;j<LL.size();j++) {
			System.out.println(LL.get(j));
		}
		
		
		
	}
	
	public static void listExample() {
		
		List<Integer> LA = new ArrayList<Integer>();
		
		List<String> LL = new LinkedList<String>();
		
		LA.add(4);
		LL.add("Hello");
		
		
		
	}
	
	
}
