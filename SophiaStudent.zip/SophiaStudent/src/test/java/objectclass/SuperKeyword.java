package objectclass;

public class SuperKeyword {
	
	String a="Hello";
	
	final String S="India"; // It will not allow u to change the value
	 
	void superMethod() {
		System.out.println("SUperMethod");
	}
	
	void changeStringValue() {
		//S="China";
		System.out.println(S);
	}

}

class SuperKeywordChild extends SuperKeyword {
	
	String a="hi";
	
	void methodSuper() {
		System.out.println(a);
		System.out.println(super.a);
		
		super.superMethod();
	}
	
	
}
