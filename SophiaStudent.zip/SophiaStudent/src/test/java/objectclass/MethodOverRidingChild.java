package objectclass;

public class MethodOverRidingChild extends MethodoverRidingParent{
	
	public void bike() {
		System.out.println("Bike is running");
	}

}
