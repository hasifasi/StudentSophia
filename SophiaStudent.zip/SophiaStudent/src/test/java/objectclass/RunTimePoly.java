package objectclass;

public class RunTimePoly {
	
	void parentMethod() {
		System.out.println("Driving");
	}

}


class childRunTimePoly extends RunTimePoly{
	
	void childMethod() {
		System.out.println("Running");
	}
}