package objectclass;

public class StaticKeyword {

	int i=4;
	
	static int j=10;
	
	
	public void methodNonStatic() {
		System.out.println(i);
	}
	
	public static void methodStatic() {
		System.out.println(j);
	}
	
	
	
	
}
