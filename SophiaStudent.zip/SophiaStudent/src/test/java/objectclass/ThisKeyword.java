package objectclass;

public class ThisKeyword {
	
	String name;
	String dept;
	
	ThisKeyword(){
		
		System.out.println("This is default constructor");
	}
	
	ThisKeyword(String name,String dept){
		this();
		this.name=name;
		this.dept=dept;
	}
	
	public void methodThisKeyword() {
		System.out.println(name +"------------"+dept);
	}
	

}
