package objectclass;

public class excercisetwo {
	
	public void methodOne() {
		
		System.out.println("This is my first program");
		
		System.out.println("Running");
		
		
		String a="hello";
		int c=3;
	
		System.out.println(a);
		System.out.println(c);
	
				
		
		
	}

}
