package objectclass;

public class Encapsulation {
	// Encapsulation mainly used for logging purpose
	private int i;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
		System.out.println(" The value of i is set and it is "+i);
	}
	
	

}
