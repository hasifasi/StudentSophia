package objectclass;

 class Interfaceapproach implements Interfaceone,Interfacetwo,Interfacethree {

	public void Trash() {
		// TODO Auto-generated method stub
		System.out.println("Trashing...");
	}

	public void Draft() {
		// TODO Auto-generated method stub
		System.out.println("Drafting...");
	}

	public void Inbox() {
		// TODO Auto-generated method stub
		System.out.println("Inboxing...");
	}
	
	public void Delete() {
		System.out.println("Deleting...");
	}
	

}










interface Interfaceone{
	void Inbox();
	void Delete();
}

interface Interfacetwo{
	void Draft();
}

interface Interfacethree{
	void Trash();
}