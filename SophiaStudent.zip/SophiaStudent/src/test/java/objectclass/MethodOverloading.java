package objectclass;

public  class MethodOverloading {
	
	
	
	
	public static void add(int i,int j) {
		int k= i+j;
		
		System.out.println(k);
	}
	
	public static void add(double x,double y) {
		double z=x+y;
		System.out.println(z);
	}
	
	public static void add(int a, int b, int c) {
		int d= a+b+c;
		System.out.println(d);
	}

}
