package objectclass;

public class MethodoverRidingParent {
	
	public void bike() {
		System.out.println("Bike is standing");
	}

}
