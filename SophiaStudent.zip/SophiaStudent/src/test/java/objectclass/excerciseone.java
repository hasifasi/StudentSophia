package objectclass;

import controlstatements.Controlvalidations;

public class excerciseone {

	public static void main(String[] args) {
		// syntax to create object [ instantiate an Object]
	//	excercisetwo S = new excercisetwo(); 		
	//	S.methodOne();
		
	//	System.out.println("****************************");
		
		//Constrol Statements
		Controlvalidations CV = new Controlvalidations();
	//	 CV.ifElseMethod();
		 
		 CV.switchCaseMethod();
	}
	
	

}
