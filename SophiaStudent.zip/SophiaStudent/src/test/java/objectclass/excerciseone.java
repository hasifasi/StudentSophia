package objectclass;

import Variables.variablesExamples;
import controlstatements.Controlvalidations;

public class excerciseone extends variablesExamples{

	public static void main(String[] args) {
		// syntax to create object [ instantiate an Object]
	//	excercisetwo S = new excercisetwo(); 		
	//	S.methodOne();
		
	//	System.out.println("****************************");
		
		//Constrol Statements
	//	Controlvalidations CV = new Controlvalidations();
	//	 CV.ifElseMethod();
		 
	//	 CV.switchCaseMethod();
	//	 CV.forLoop();
		
		
		//Variables
		variablesExamples V= new variablesExamples();
		V.variableMethodOne();
		System.out.println("******************");
		V.variableMethodTwo();
		
		// THe Method is Private
	//	V.privateAccessmodifier();
		
		
		V.methodFour();
		
		
		// THis is default Modifier from a differnt package
	//	V.defaultModifier();
		
		
		// This is example of protected Modifier using EXTENDS keyword
		excerciseone e= new excerciseone();
		e.protectAccModifier();
	
	}
	
	

}
