package objectclass;

public class ExplainContructors {
	
	
	int a;
	String b;
	
	//Constructors
	ExplainContructors(){
		a=4;
		b="Hello";
	}
	
	ExplainContructors(String k){
		System.out.println("Inside Constructors");
		
		System.out.println(k);
	}
	
	
	
	public void methodContructor() {
		System.out.println(a);
		System.out.println(b);
	}
   

}
