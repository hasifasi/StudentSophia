package objectclass;

public abstract class JavaphoneVone {
	
	//Method with body
	public void calling() {
		System.out.println("Calling.....");
	}
	
	// Method without Body
	public abstract void photos();
	
	public abstract void music();
}

	


 abstract class JavaPhoneVtwo extends JavaphoneVone{
	
	public void photos() {
		System.out.println("Photos...");
	}
	
	public abstract void music();
	

}
 
  class JavaPhoneVthree extends JavaPhoneVtwo{
	 
	 
	 public void music() {
		 System.out.println("Music.........");
	 }
 }
  
  
  
  
  
  
  
