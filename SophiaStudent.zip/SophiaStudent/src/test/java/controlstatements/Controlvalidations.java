package controlstatements;

public class Controlvalidations {
	
	
	@SuppressWarnings("unused")
	public void ifElseMethod() {
		
		if(true) {
			System.out.println("Inside if loop");
		}
		
		if(5>2) {
			System.out.println("5 is greater than 2");
		}
		
		if(1>3){
			System.out.println(" 1 is greater than 3");
		}else {
			System.out.println("1 is lesser than 3");
		}
		
		
		if(1>3) {
			System.out.println("failure");
		}else if(2>3) {
			System.out.println("Failure");
		}else {
			System.out.println("Success");
		}
	}
	
	public void switchCaseMethod() {
		int number=50;
		
		switch(number) {
		
		case 10: System.out.println("The value is 10");
		break;
		case 20: System.out.println("The value is 20");
		break;
		case 30: System.out.println("The value is 30");
		break;
		case 40: System.out.println("The value is 40");
		break;
		default : System.out.println(" Nothing matched");
		
		}
		
	}
	
	public void forLoop() {
		
		
		int i;
		for(i=0;i<5;i++) {
			System.out.println(i);
		}
		
	}
	
	public void whileLoop() {
		int i=11;
		while(i<10) {
			System.out.println(i);
			i++;
		}
		
	}
	
	public void doWhileLoop() {
		int i=11;
		do {
			System.out.println(i);
			i++;
		}while(i<10);
		
	}
	

}
