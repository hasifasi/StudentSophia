package Variables;

public class variablesExamples {
	//Instance variables
	int j=1;
	String B="World";
	
	
	//Static Variables =  It will be loaded at the class area
	static int k=5;
	static String C=" Hello how are U?";
	
	
	public  void variableMethodOne() {
		//Local variables
		int i=0;
		String A="Hello";
		
		System.out.println(i);
		System.out.println(A);
		
		System.out.println(j);
		System.out.println(B);
		
	}
	
	public void variableMethodTwo() {
		
		System.out.println(j);
		System.out.println(B);
	}
	
	private void privateAccessmodifier() {
		System.out.println("Private");
	}
	
	public void methodFour() {
		privateAccessmodifier();
	}
	
	void defaultModifier() {
		System.out.println(" THis is default Modifier");
	}
	
	protected void protectAccModifier() {
		System.out.println("Protected");
	}

}
