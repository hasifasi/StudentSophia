package Variables;
import Variables.variablesExamples;
public class AccessModifier {
	
	
	public void accMod() {
		
		variablesExamples VE = new variablesExamples();
		
		VE.defaultModifier();
		VE.protectAccModifier();
		
	}
	
	
	
	
	

}
